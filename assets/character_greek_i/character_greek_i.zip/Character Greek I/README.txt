Hi, I'm KrinWolf 
You can use this character in any project:

This archive have 6 animation exported on .png
-Idle
-Walk
-Attack
-Jump-start
-Jump-Keep
-Die

Animations are made in Dragon Bones 5.6.3 (Open .dbproj for edit & export animations)
With this you can create new animations & export spritesheets o json files.

Use the animations on your game engine (Godot, Unity. Phaser, etc)
They have the respectives runtimes.http://dragonbones.com/en/download.html#runLibrary 
Godot Compiled Dragons Bones Module https://www.godotdragonbones.com/

The images are compressed with PNGQuant PNG 8Bits Index 128 (Colors) for the best size and performance.

Do not forget to add to your favorites. It is very important for me ;)

Tags:
2d, characert, greek, animation, human, soldier, platform, ancient, historic, fantasy

License CC BY 4.0 - Atribution "Krinwolf.com - Tony Puglieso"
